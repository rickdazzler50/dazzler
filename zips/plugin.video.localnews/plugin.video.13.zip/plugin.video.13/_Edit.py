import xbmcaddon

MainBase = 'http://firestickplusmancomlu.com/Addon/home.txt'
addon = xbmcaddon.Addon('plugin.video.LocalNews')